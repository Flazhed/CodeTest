﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CodeTestOntame;
using CodeTestOntame.Control;
using CodeTestOntame.Entity;

namespace Tests
{
    [TestClass]
    public class ControllerTests
    {
        private IController controller;

        public ControllerTests()
        {
            this.controller = new Controller();
        }

        [TestMethod]
        public void GetAllJobsFromCityTest()
        {
            string cityString = "new-york-ny-united-states";

            List<Job> jobs = controller.GetAllJobsFromCity(cityString);
            Assert.IsTrue(jobs.Count > 0); //Hard to do a good assertion when getting results from an outside sorce. Therefore I just check if there are jobs in the list
            Assert.IsTrue(jobs[0].Headline.Length > 0); //Same thing here. I don't know what to assert, therefore I check if something is set on the attribute.
            Assert.IsTrue(jobs[0].Url.Length > 0);
            Assert.IsTrue(jobs[0].JobDescription.Length > 0);
        }
    }
}
