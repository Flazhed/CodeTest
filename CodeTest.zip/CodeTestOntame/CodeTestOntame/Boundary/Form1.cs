﻿using System;
using System.Data;
using System.Windows.Forms;
using CodeTestOntame.Control;

namespace CodeTestOntame
{
    public partial class Form1 : Form
    {
        private readonly IController controller;
        private DataTable table;

        public Form1()
        {
            InitializeComponent();
            controller = new Controller();
        }


        private void InitTable()
        {
            table = new DataTable("Jobs");
            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("Headline", typeof(string));
            table.Columns.Add("Url", typeof(string));
            table.Columns.Add("Experince Req", typeof(bool));
            table.Columns.Add("Description", typeof(string));
            dataGridView1.DataSource = table;
        }

        private void LoadJobs()
        {
            var jobs = controller.GetAllJobsFromCity("new-york-ny-united-states");
            if (jobs.Count > 0)
                foreach (var job in jobs)
                    table.Rows.Add(job.Id, job.Headline, job.Url, job.ExperinceRequired, job.JobDescription);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitTable();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Controls.Remove(button1);
            LoadJobs();
        }
    }
}