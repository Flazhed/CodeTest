﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using CodeTestOntame.Entity;
using HtmlAgilityPack;

namespace CodeTestOntame.Control
{
    public class ScraperService
    {
        /// <summary>
        /// Method is reponsible of using help-methods, in order to scrape information about jobs
        /// in a given city.
        /// </summary>
        /// <param name="cityString">Part-URL of a given city bound for scraping.</param>
        /// <returns>A list of Job entitites succesfully scraped.</returns>
        public List<Job> ScrapeJobsFromCity(string cityString)
        {
            //Define the string for the given city, then load the html using HtmlAgilityPack
            string urlString = "https://www.spotify.com/us/jobs/opportunities/all/all/" + cityString + "/";
            HtmlWeb web = new HtmlWeb();
            var doc = web.Load(urlString);

            //Using the Xpath from HTML inspection, we end up with a bunch of nodes containing information about
            // the jobs
            var jobListingNodes = doc.DocumentNode.SelectNodes("//*[@class=\"job-listing\"]");
            List<Job> jobs = MapNodesToJobs(jobListingNodes); //Use helpmethod to map these nodes into Job Entities.
            DetectedExperince(jobs); //Use helpmethod to detect if professional experince is needed.

            return jobs;

        }

        /// <summary>
        /// Tries to detect if the given list of Jobs require any professional experince.
        /// Uses help-method to get a list of nodes, containing information about the job.
        /// Then uses a regular expression to test for indication of needed experince.
        /// </summary>
        /// <param name="jobs">List of Jobs previously scraped.</param>
        private void DetectedExperince(List<Job> jobs)
        {
            //Runtime on this method is no where near optimal. Would like to make method asynch, in order to fetch multiple
            //URLS at a time.
            HtmlNodeCollection nodes;
            Regex regex = new Regex(@"(\bprofessional experience)");
            Match match;
            foreach (Job job in jobs)
            {
                nodes = GetJobInformation(job.Url);
                if (nodes != null) { 
                    foreach (var node in nodes)
                    {
                        match = regex.Match(node.InnerText);
                        if (match.Success)
                        {
                            job.ExperinceRequired = true;
                        }
                    }
                }
            }
        }


        /// <summary>
        /// Method fetches HTML-Listitems in a nodecolletion. In the nodes is found information about the job
        /// and the expectations of the applicant.
        /// </summary>
        /// <param name="jobUrl">URL to a specific job opening</param>
        private HtmlNodeCollection GetJobInformation(string jobUrl)
        {
            string urlString = "https://www.spotify.com/" + jobUrl;

            HtmlWeb web = new HtmlWeb();
            var doc = web.Load(urlString);
            var nodes = doc.DocumentNode.SelectNodes("//*[@class=\"job-description\"]//li");

            return nodes;

        }

        /// <summary>
        /// Method responsible of mapping HtmlNodes into Job Entities.
        /// Using selctors the different values are found
        /// </summary>
        /// <param name="nodes">Previously scraped HTML-nodes</param>
        /// <returns>A List of mapped Job entities.</returns>
        private List<Job> MapNodesToJobs(HtmlNodeCollection nodes)
        {
            int idCounter = 1;
            List<Job> jobs = new List<Job>();
            string headline, url, description;
            foreach (var node in nodes)
            {
                headline = node.SelectSingleNode("h3[@class=\"job-title\"]").InnerText;
                url = node.SelectSingleNode("h3[@class=\"job-title\"]//a[@href]").Attributes["href"].Value;
                description = node.ChildNodes.First(item => item.Name == "p").InnerText;
                jobs.Add(new Job() {Headline = headline, Url = url, JobDescription = description, Id = idCounter, ExperinceRequired = false});
                idCounter++;
            }
            return jobs;
        }

    }
}
