﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CodeTestOntame.Entity;

namespace CodeTestOntame.Control
{
    public class Controller : IController
    {
        private ScraperService scraper;

        public Controller()
        {
            this.scraper = new ScraperService();
        }


        public List<Job> GetAllJobsFromCity(string cityString)
        {
            return scraper.ScrapeJobsFromCity(cityString);
        }
    }
}
