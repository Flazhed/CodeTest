﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CodeTestOntame.Control;
using CodeTestOntame.Entity;

namespace CodeTestOntame
{
    public partial class Form1 : Form
    {
        private IController controller;
        private DataTable table;
        public Form1()
        {
            InitializeComponent();
            this.controller = new Controller();
            
        }


        private void InitTable()
        {
            table = new DataTable("Jobs");
            table.Columns.Add("Id", typeof(int));
            table.Columns.Add("Headline", typeof(string));
            table.Columns.Add("Url", typeof(string));
            table.Columns.Add("Experince Req", typeof(bool));
            table.Columns.Add("Description", typeof(string));
            dataGridView1.DataSource = table;
            
        }

        private void LoadJobs()
        {
            List<Job> jobs = controller.GetAllJobsFromCity("new-york-ny-united-states");
            if (jobs.Count > 0)
            {
                foreach (Job job in jobs)
                {
                    table.Rows.Add(job.Id, job.Headline, job.Url, job.ExperinceRequired, job.JobDescription);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitTable();
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Controls.Remove(button1);
            LoadJobs();

        }
    }
}
